Test room (dev:demo): robot task export

Files
  scene.xml     MuJoCo (MJCF) scene: floor, every object as a static body, every movable part as a jointed child body
  meshes/*.obj  triangle meshes in each body frame (placement scale baked in)
  task.json     goal, ordered steps, success criterion and joint table

Frames and units
  Z-up, metres, radians. The room was authored Y-up; it maps as x -> x, y -> z, z -> -y.
  Floor plane at z = -0.55. Each object body sits at its placement, turned about +Z by its yaw.

Joints (body and joint share the name <object>__<part>)
  nightstand__top_drawer  slide  0 .. 0.3 m
  jewelry_box__lid        hinge  0 .. 1.9 rad
  Passive: slide damping 4, armature 0.05, frictionloss 0.3; hinge damping 0.3, armature 0.01, frictionloss 0.02.
  There are no actuators: a robot opens the parts by contact, or add <position joint="..."/> actuators to script them.

Collision
  Each mesh collides through its convex hull. Parts of the same object do not collide with each other
  (their hulls overlap by construction); for contact-rich work replace the hulls with a convex decomposition.
  Masses come from hull volume at 400 kg/m3; set density or mass per geom to match real furniture.

Task
  Escape "Test room": open nightstand.top_drawer, take note, open jewelry_box.lid (code 0412), take door_key, exit.
  1. open nightstand.top_drawer: drive nightstand__top_drawer to 0.3
  2. take note from nightstand.top_drawer
  3. open jewelry_box.lid: drive jewelry_box__lid to 1.9 (code 0412)
  4. take door_key from jewelry_box.lid
  5. exit (key door_key)
  Success when every opened part reaches 90% of its travel (nightstand__top_drawer >= 0.27 m, jewelry_box__lid >= 1.71 rad); the items note, door_key are taken; the exit is unlocked with door_key.

Load
  python -m mujoco.viewer --mjcf=scene.xml
